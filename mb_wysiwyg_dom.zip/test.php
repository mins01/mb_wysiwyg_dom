<?
print('$_POST <br>');
print('<xmp>');
print_r($_POST);
print('</xmp>');
print('<hr>');
print('$_GET <br>');
print('<xmp>');
print_r($_GET);
print('</xmp>');
?>
